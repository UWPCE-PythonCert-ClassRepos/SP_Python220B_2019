"""Honestly looks like a useless standalone at the moment..."""


def get_latest_price():
    """I assume, suppose to get the latest price of an item, currently not doing anything useful"""
    return 24
    # Raise an exception to force the user to Mock its output
