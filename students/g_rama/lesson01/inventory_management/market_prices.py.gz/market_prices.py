"""Market prices class"""


def get_latest_price(item_code):  # pylint: disable=unused-argument
    """Function to the the latest price"""
    return 24
    # Raise an exception to force the user to Mock its output
