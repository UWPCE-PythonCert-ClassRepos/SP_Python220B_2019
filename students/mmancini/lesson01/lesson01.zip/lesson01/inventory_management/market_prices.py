"""
market_prices
"""

# .pylintrc disable = unused-argument

def get_latest_price(item_code):
    """ get latest price """
    return 24
    # Raise an exception to force the user to Mock its output
