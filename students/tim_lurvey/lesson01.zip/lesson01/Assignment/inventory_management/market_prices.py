#!/usr/env/bin python
""" Returns market prices for item code"""


def get_latest_price(item_code):  # pylint: disable=unused-argument
    """method docstring"""
    return 24
    # Raise an exception to force the user to Mock its output
