"""Module for getting market prices"""
def get_latest_price():
    """Gets latest price"""
    return 24
    # Raise an exception to force the user to Mock its output
