"""
This is the multiplier function
"""
class Multiplier():

    @staticmethod
    def calc(operand_1, operand_2):
        return operand_1 * operand_2
