"""
This is the addition function
"""
class Adder():
    """
    This is the addition class
    """
    @staticmethod
    def calc(operand_1, operand_2):
        """
        This is the addition staticmethod
        """
        return operand_1 + operand_2
