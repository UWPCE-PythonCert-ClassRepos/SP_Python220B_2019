"""
This is the divider function
"""
class Divider():

    @staticmethod
    def calc(operand_1, operand_2):
        return operand_1 / operand_2
