class InsufficientOperands(Exception):
    pass
