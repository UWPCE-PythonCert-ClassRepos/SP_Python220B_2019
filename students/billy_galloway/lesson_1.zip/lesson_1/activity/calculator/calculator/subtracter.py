"""
subtracter module
"""
class Subtracter():
    """
    subtracter class
    """
    @staticmethod
    def calc(operand_1, operand_2):
        """
        subtracter function
        """
        return operand_1 - operand_2
