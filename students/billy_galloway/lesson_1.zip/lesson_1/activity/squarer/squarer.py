class Squarer(object):

    @staticmethod
    def calc(operand):
        return operand**2