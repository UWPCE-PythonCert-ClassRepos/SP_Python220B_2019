"""
get latest price exception
"""
def get_latest_price(item_code):
    """
    return code for exception
    """
    return 24
    # Raise an exception to force the user to Mock its output
