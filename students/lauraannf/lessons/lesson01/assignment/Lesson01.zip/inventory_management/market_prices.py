""" market prices"""


def get_latest_price(item_code):
    """ get market price"""
    return 24
    # Raise an exception to force the user to Mock its output
